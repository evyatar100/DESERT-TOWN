#!/usr/bin/env python3
"""Read-only gate: is map slot N safe to install into an RPG Maker XP / Essentials project?
Ships inside the export zip; needs only Python 3 + rubymarshal. why: dec:dt-50"""
from __future__ import annotations

import collections
import json
import re
import sys
from pathlib import Path

EXIT_SAFE, EXIT_UNSAFE, EXIT_USAGE, EXIT_UNVERIFIABLE = 0, 1, 2, 3
RESERVED_MAP_IDS = frozenset({999})   # Essentials random-dungeon map
MAX_SUGGESTIONS = 5
MAX_SLOT = 999
RESULT_PREFIX = "DT_SLOT_CHECK"
USAGE = (
    "Usage: check_map_slot.py <game_root> <slot>\n"
    "Exit: 0 safe | 1 slot unsafe (free ids suggested) | 2 bad arguments/game root\n"
    "      | 3 cannot verify (rubymarshal missing, data unreadable). Never writes.\n"
    "The last stdout line is always `DT_SLOT_CHECK {json}`."
)


def read_map_info_names(data_dir: Path) -> dict[int, str]:
    # why: deferred import so --help works and a missing package fails loudly in main.
    from rubymarshal.reader import loads
    out: dict[int, str] = {}
    for key, info in loads((data_dir / "MapInfos.rxdata").read_bytes()).items():
        name = ""
        try:
            raw = (getattr(info, "attributes", None) or {}).get("@name")
            name = raw.decode("utf-8", "replace") if isinstance(raw, bytes) else str(raw or "")
        except Exception:
            name = ""
        out[int(key)] = name
    return out


def read_start_map_id(data_dir: Path) -> int | None:
    from rubymarshal.reader import loads
    attrs = getattr(loads((data_dir / "System.rxdata").read_bytes()), "attributes", None) or {}
    value = attrs.get("@start_map_id")
    return int(value) if value is not None else None


def map_ids_on_disk(data_dir: Path) -> set[int]:
    return {int(m.group(1)) for p in data_dir.glob("Map*.rxdata")
            if (m := re.fullmatch(r"Map(\d+)\.rxdata", p.name, re.I))}


def pbs_map_id_references(pbs_dir: Path) -> dict[int, set[str]]:
    """Every map id an Essentials PBS file already carries metadata for."""
    refs: dict[int, set[str]] = collections.defaultdict(set)

    def read(name: str) -> str:
        p = pbs_dir / name
        return p.read_text(encoding="utf-8-sig") if p.is_file() else ""

    meta = read("map_metadata.txt")
    for mo in re.finditer(r"^\[(\d+)\]", meta, re.M):
        refs[int(mo.group(1))].add("map_metadata section")
    for mo in re.finditer(r"^HealingSpot\s*=\s*(\d+)", meta, re.M):
        refs[int(mo.group(1))].add("map_metadata HealingSpot")
    for mo in re.finditer(r"^\[(\d+)\]", read("encounters.txt"), re.M):
        refs[int(mo.group(1))].add("encounters section")
    for mo in re.finditer(r"^(?:Home|HealingSpot)\s*=\s*(\d+)", read("metadata.txt"), re.M):
        refs[int(mo.group(1))].add("metadata Home")
    for mo in re.finditer(r"^Point\s*=\s*\d+,\d+,[^,\n]*,[^,\n]*,(\d+)", read("town_map.txt"), re.M):
        refs[int(mo.group(1))].add("town_map Point")
    for line in read("map_connections.txt").splitlines():
        parts = line.strip().split(",")
        if line.strip().startswith("#") or len(parts) < 6:
            continue
        if parts[0].strip().isdigit() and parts[3].strip().isdigit():
            refs[int(parts[0])].add("map_connections")
            refs[int(parts[3])].add("map_connections")
    return dict(refs)


class SlotState:
    """Everything that makes a map id unusable, gathered once per game."""

    def __init__(self, game_root: Path) -> None:
        data = game_root / "Data"
        self.names = read_map_info_names(data)
        self.on_disk = map_ids_on_disk(data)
        self.start_map = read_start_map_id(data)
        self.pbs = pbs_map_id_references(game_root / "PBS")

    def reasons(self, slot: int) -> list[tuple[str, str]]:
        out: list[tuple[str, str]] = []
        if slot in RESERVED_MAP_IDS:
            out.append(("reserved-map-id", f"map id {slot} is reserved by Essentials"))
        if slot in self.on_disk:
            named = f" (MapInfos calls it {self.names[slot]!r})" if self.names.get(slot) else ""
            out.append(("map-slot-occupied", f"Data/Map{slot:03d}.rxdata already exists{named}"))
        if slot == self.start_map:
            out.append(("start-map", f"map {slot} is System.rxdata's start_map_id"))
        if slot in self.pbs:
            out.append(("pbs-metadata-inherited", "already has Essentials metadata (a new map would "
                        "inherit its name, connections, encounters): " + ", ".join(sorted(self.pbs[slot]))))
        if slot in self.names and slot not in self.on_disk:
            out.append(("orphan-mapinfo", f"MapInfos has an entry {slot} with no map file"))
        return out

    def free_ids(self, count: int = MAX_SUGGESTIONS) -> list[int]:
        found: list[int] = []
        for cand in range(1, MAX_SLOT + 1):
            if not self.reasons(cand):
                found.append(cand)
                if len(found) == count:
                    break
        return found


def emit(payload: dict) -> None:
    print(f"{RESULT_PREFIX} {json.dumps(payload, sort_keys=True)}")


def main(argv: list[str]) -> int:
    if len(argv) != 2 or not argv[1].isdigit():
        print(USAGE, file=sys.stderr)
        emit({"status": "error", "exit": EXIT_USAGE, "reason": "usage: check_map_slot.py <game_root> <slot>"})
        return EXIT_USAGE
    root, slot = Path(argv[0]).expanduser().resolve(), int(argv[1])
    if not (root / "Data" / "MapInfos.rxdata").is_file():
        print(f"{root} is not an RPG Maker XP project: Data/MapInfos.rxdata not found.")
        emit({"status": "error", "exit": EXIT_USAGE, "reason": "game root has no Data/MapInfos.rxdata"})
        return EXIT_USAGE
    try:
        state = SlotState(root)
    except ImportError:
        print("CANNOT VERIFY: the Python package 'rubymarshal' is not installed, so the game's\n"
              "files cannot be read. Run `pip install rubymarshal` and re-run this check.\n"
              "Do NOT install the map until this check has run and exited 0.")
        emit({"status": "cannot-verify", "exit": EXIT_UNVERIFIABLE, "reason": "rubymarshal not installed"})
        return EXIT_UNVERIFIABLE
    except Exception as exc:
        print(f"CANNOT VERIFY: could not read the game's data ({type(exc).__name__}: {exc}).\n"
              "Do NOT install the map.")
        emit({"status": "cannot-verify", "exit": EXIT_UNVERIFIABLE, "reason": f"{type(exc).__name__}: {exc}"})
        return EXIT_UNVERIFIABLE

    reasons = state.reasons(slot)
    if not reasons:
        print(f"Map slot {slot} is free: no map file, no MapInfos entry, no PBS metadata.")
        emit({"status": "safe", "exit": EXIT_SAFE, "slot": slot})
        return EXIT_SAFE
    free = state.free_ids()
    print(f"Map slot {slot} is NOT safe to install into:")
    for _code, message in reasons:
        print(f"  - {message}")
    print("Installing there would overwrite or silently re-skin an existing map.")
    print(f"Free map ids you can use instead: {', '.join(map(str, free))}")
    print(f"To use one, name the file Map<id as 3 digits>.rxdata (e.g. Map{free[0]:03d}.rxdata) and "
          "re-run this check with that id.")
    emit({"status": "unsafe", "exit": EXIT_UNSAFE, "slot": slot,
          "reasons": [c for c, _ in reasons], "free_ids": free})
    return EXIT_UNSAFE


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
