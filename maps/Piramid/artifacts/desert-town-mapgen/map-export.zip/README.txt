DesertTown map export -- 36x33 tiles

This zip does NOT touch your game folder automatically -- follow these
steps IN ORDER (RPG-midburn). Whoever installs this -- a person or an AI
agent -- must pass step 0 before touching Data/ or Graphics/.

0. GATE -- check the map slot is free. Do this first, change nothing until it passes:
   python3 check_map_slot.py <GAME_ROOT> 576
   (<GAME_ROOT> is the game folder that contains Data/ and Graphics/. The script is
   read-only, needs Python 3 and `pip install rubymarshal`, and never writes anything.)
   - Exit code 0 = slot is free. Continue to step 1.
   - Any non-zero exit = STOP. Do not copy anything into Data/ or Graphics/.
     Exit 1: the slot is taken. The last output line is `DT_SLOT_CHECK {json}` with a
     `free_ids` list. Take the first free id N, then name the map file
     Map<N as 3 digits>.rxdata instead of Map576.rxdata, and re-run the script with N
     as the last argument. Install only once that run exits 0.
     Exit 2: bad arguments or not a game folder -- fix the command.
     Exit 3: the check could not run (usually rubymarshal is missing) -- install it
     and re-run. A check that could not run is NOT a pass; never skip it.
   - A file merely not existing is NOT enough: a free-looking id can still carry the old
     map's name, connections and encounters. The script checks all of that; do not
     replace it with your own look at the Maps tree.
   - Never overwrite an existing Data/Map*.rxdata or an existing tileset entry.

1. Register the tileset:
   a. Copy Tileset_North_Gate_Camp__imported_-slot576-North_Gate_Camp_imported.png into Graphics/Tilesets/.
   b. Open RPG Maker XP -> Database -> Tilesets. Add one new entry
      pointing at Tileset_North_Gate_Camp__imported_-slot576-North_Gate_Camp_imported.png, and note the ID it gets assigned.
   c. If that ID is DIFFERENT from 22 (the "Tileset ID" you
      entered when you ran this export) -- STOP here. Go back to the
      Export step in the app and re-export with the real ID entered
      instead. Map576.rxdata references tileset 22
      internally, so a mismatch does not mean a slightly-wrong tileset:
      it means RPG Maker draws this map's tiles from WHATEVER tileset
      already holds that ID today. Since this map uses many tile ids
      well past 384, and any of your existing tilesets is almost
      certainly a shorter sheet, most or all of the picture will render
      as solid black/blank -- "the background is not shown" is exactly
      this symptom, not a sign the export itself is empty. Only
      continue to step 2 once the ID you exported with matches the ID
      RPG Maker actually assigned.

2. Copy Map576.rxdata into Data/ (or Map<N>.rxdata if step 0 gave you another id).
   - Only after step 0 exited 0 for exactly that id. Do not overwrite an existing file.

passability.csv and the .json are reference only (see their own headers) --
this export never writes Data/Tilesets.rxdata, so passability/priority
still needs the one-time manual Database step above.

3. Traced background objects -- per-object Database steps:
   - "ambulance" (Layer 3): set tileset rows 171-175 (tile ids 1744-1782) to Priority 5 (the per-tile values in passability.csv, 1-5, are more exact), so the player can walk behind it.
   - "pyramid" (Layer 3): set tileset rows 176-190 (tile ids 1784-1896) to Priority 3 (the per-tile values in passability.csv, 1-3, are more exact), so the player can walk behind it.

4. Hard borders -- edges the player cannot cross:
   In Database -> Tilesets -> Passage (4 dir), turn OFF the named arrow(s) on the
   listed tile ids. Installing agent: OR the mask into @passages[id] (down 0x01,
   left 0x02, right 0x04, up 0x08) and never clear a bit that is already set.
   Each border sits on BOTH tiles of the edge, so it blocks from either side.
   - block down (mask 0x01): tile id(s) 700-703, 968-972, 1150-1151, 1416, 1752-1754, 1784-1785, 1791, 1848
   - block up (mask 0x08): tile id(s) 708-711, 976-980, 1158-1159, 1424, 1760-1762, 1792-1793, 1799, 1856

GRID, SCALE AND PADDING
  Grid size: 32 px per square, offset X 0 Y 0.
  Map: 36 x 33 whole tiles (1152 x 1056 px).
  Scale: 1x. The art is exported at its own size, no resampling.
  Nothing was padded: the map already sat on whole grid squares.

TILESET SHEET LAYOUT -- read this before editing the PNG by hand

   The sheet is your map, not a bag of tiles. It is cut into 5 vertical
   strip(s) of 8 tiles (256px) each, stacked top to bottom:
     strip 1: map columns 1-8, all 33 map rows -> sheet rows 1-33
     strip 2: map columns 9-16, all 33 map rows -> sheet rows 35-67
     strip 3: map columns 17-24, all 33 map rows -> sheet rows 69-101
     strip 4: map columns 25-32, all 33 map rows -> sheet rows 103-135
     strip 5: map columns 33-36, all 33 map rows -> sheet rows 137-169
   The last strip only uses 4 of its 8 columns -- the rest is transparent padding.

   A solid CYAN row separates one strip from the next. No map tile ever
   points at a cyan tile. Leave the cyan rows where they are: every tile
   id is its position on this sheet, so inserting or deleting a row shifts
   every id below it and the .rxdata would then draw the wrong picture.

   To fix a tile: find it on the sheet where it sits on the map, paint over
   it in place, save, and copy the PNG back into Graphics/Tilesets/. Tile ids
   do not change, so the map keeps working with no re-export.

   Keep the PNG exactly 256px wide and its height a multiple of 32px.

   Below the last strip, after one more cyan row, sit the extra cut-out
   tiles: transparent-masked copies of placed sprites and traced objects,
   used on layers 2/3. Each object is its own block, starting on a fresh row
   and shaped like the object on the map (an object wider than 8 tiles is cut
   into stacked 8-column strips). Blocks never share a sheet row. A tile in a
   block that no map cell uses is just unused space.

   (Strip-and-stack layout adopted from Evyatar's assets-factory/
   create_tileset.py in github.com/evyatar100/DESERT-TOWN.)
