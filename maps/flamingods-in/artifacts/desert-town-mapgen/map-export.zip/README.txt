DesertTown map export -- 39x29 tiles

This zip does NOT touch your game folder automatically -- follow these
steps IN ORDER (RPG-midburn). Whoever installs this -- a person or an AI
agent -- must pass step 0 before touching Data/ or Graphics/.

0. GATE -- check the map slot is free. Do this first, change nothing until it passes:
   python3 check_map_slot.py <GAME_ROOT> 99
   (<GAME_ROOT> is the game folder that contains Data/ and Graphics/. The script is
   read-only, needs Python 3 and `pip install rubymarshal`, and never writes anything.)
   - Exit code 0 = slot is free. Continue to step 1.
   - Any non-zero exit = STOP. Do not copy anything into Data/ or Graphics/.
     Exit 1: the slot is taken. The last output line is `DT_SLOT_CHECK {json}` with a
     `free_ids` list. Take the first free id N, then name the map file
     Map<N as 3 digits>.rxdata instead of Map099.rxdata, and re-run the script with N
     as the last argument. Install only once that run exits 0.
     Exit 2: bad arguments or not a game folder -- fix the command.
     Exit 3: the check could not run (usually rubymarshal is missing) -- install it
     and re-run. A check that could not run is NOT a pass; never skip it.
   - A file merely not existing is NOT enough: a free-looking id can still carry the old
     map's name, connections and encounters. The script checks all of that; do not
     replace it with your own look at the Maps tree.
   - Never overwrite an existing Data/Map*.rxdata or an existing tileset entry.

1. Register the tileset:
   a. Copy Tileset_flamingo-inside-slot99-flamingo-inside.png into Graphics/Tilesets/.
   b. Open RPG Maker XP -> Database -> Tilesets. Add one new entry
      pointing at Tileset_flamingo-inside-slot99-flamingo-inside.png, and note the ID it gets assigned.
   c. If that ID is DIFFERENT from 568 (the "Tileset ID" you
      entered when you ran this export) -- STOP here. Go back to the
      Export step in the app and re-export with the real ID entered
      instead. Map099.rxdata references tileset 568
      internally, so a mismatch does not mean a slightly-wrong tileset:
      it means RPG Maker draws this map's tiles from WHATEVER tileset
      already holds that ID today. Since this map uses many tile ids
      well past 384, and any of your existing tilesets is almost
      certainly a shorter sheet, most or all of the picture will render
      as solid black/blank -- "the background is not shown" is exactly
      this symptom, not a sign the export itself is empty. Only
      continue to step 2 once the ID you exported with matches the ID
      RPG Maker actually assigned.

2. Copy Map099.rxdata into Data/ (or Map<N>.rxdata if step 0 gave you another id).
   - Only after step 0 exited 0 for exactly that id. Do not overwrite an existing file.

passability.csv and the .json are reference only (see their own headers) --
this export never writes Data/Tilesets.rxdata, so passability/priority
still needs the one-time manual Database step above.

3. Traced background objects -- per-object Database steps:
   - "toilet" (Layer 3): set tileset rows 151-156 (tile ids 1584-1625) to Priority 3 (the per-tile values in passability.csv, 1-3, are more exact), so the player can walk behind it.
   - "oven" (Layer 3): set tileset rows 157-159 (tile ids 1632-1652) to Priority 3 (the per-tile values in passability.csv, 1-3, are more exact), so the player can walk behind it.
   - "sofa" (Layer 3): set tileset rows 160-162 (tile ids 1656-1678) to Priority 3 (the per-tile values in passability.csv, 1-3, are more exact), so the player can walk behind it.
   - "sofa 2" (Layer 3): set tileset rows 163-167 (tile ids 1680-1713) to Priority 5 (the per-tile values in passability.csv, 1-5, are more exact), so the player can walk behind it.
   - "shower curton" (Layer 3): set tileset rows 168-174 (tile ids 1720-1771) to Priority 5 (the per-tile values in passability.csv, 1-5, are more exact), so the player can walk behind it.
   - "shower" (Layer 3): set tileset rows 175-180 (tile ids 1776-1816) to Priority 5 (the per-tile values in passability.csv, 1-5, are more exact), so the player can walk behind it.

4. Hard borders -- edges the player cannot cross:
   In Database -> Tilesets -> Passage (4 dir), turn OFF the named arrow(s) on the
   listed tile ids. Installing agent: OR the mask into @passages[id] (down 0x01,
   left 0x02, right 0x04, up 0x08) and never clear a bit that is already set.
   Each border sits on BOTH tiles of the edge, so it blocks from either side.
   - block down (mask 0x01): tile id(s) 1188-1191, 1424-1427
   - block left (mask 0x02): tile id(s) 1155, 1163, 1171, 1179
   - block down + left (mask 0x03): tile id(s) 1187
   - block right (mask 0x04): tile id(s) 1169, 1178, 1186
   - block down + right (mask 0x05): tile id(s) 1154
   - block left + right (mask 0x06): tile id(s) 1170
   - block up (mask 0x08): tile id(s) 1195-1199, 1432-1435
   - block right + up (mask 0x0c): tile id(s) 1162

GRID, SCALE AND PADDING
  Grid size: 32 px per square, offset X 8 Y 30.
  Map: 39 x 29 whole tiles (1248 x 928 px).
  Scale: 1x. The art is exported at its own size, no resampling.
  Padded with the map's edge colour (art px, before scaling): left 24, right 24, top 2, bottom 30, so the map is whole tiles.

TILESET SHEET LAYOUT -- read this before editing the PNG by hand

   The sheet is your map, not a bag of tiles. It is cut into 5 vertical
   strip(s) of 8 tiles (256px) each, stacked top to bottom:
     strip 1: map columns 1-8, all 29 map rows -> sheet rows 1-29
     strip 2: map columns 9-16, all 29 map rows -> sheet rows 31-59
     strip 3: map columns 17-24, all 29 map rows -> sheet rows 61-89
     strip 4: map columns 25-32, all 29 map rows -> sheet rows 91-119
     strip 5: map columns 33-39, all 29 map rows -> sheet rows 121-149
   The last strip only uses 7 of its 8 columns -- the rest is transparent padding.

   A solid CYAN row separates one strip from the next. No map tile ever
   points at a cyan tile. Leave the cyan rows where they are: every tile
   id is its position on this sheet, so inserting or deleting a row shifts
   every id below it and the .rxdata would then draw the wrong picture.

   To fix a tile: find it on the sheet where it sits on the map, paint over
   it in place, save, and copy the PNG back into Graphics/Tilesets/. Tile ids
   do not change, so the map keeps working with no re-export.

   Keep the PNG exactly 256px wide and its height a multiple of 32px.

   Below the last strip, after one more cyan row, sit the extra cut-out
   tiles: transparent-masked copies of placed sprites and traced objects,
   used on layers 2/3. Each object is its own block, starting on a fresh row
   and shaped like the object on the map (an object wider than 8 tiles is cut
   into stacked 8-column strips). Blocks never share a sheet row. A tile in a
   block that no map cell uses is just unused space.

   (Strip-and-stack layout adopted from Evyatar's assets-factory/
   create_tileset.py in github.com/evyatar100/DESERT-TOWN.)
