DesertTown map export -- 13x24 tiles

This zip does NOT touch your game folder automatically -- follow these
steps IN ORDER (RPG-midburn). Whoever installs this -- a person or an AI
agent -- must pass step 0 before touching Data/ or Graphics/.

0. GATE -- check the map slot is free. Do this first, change nothing until it passes:
   python3 check_map_slot.py <GAME_ROOT> 116
   (<GAME_ROOT> is the game folder that contains Data/ and Graphics/. The script is
   read-only, needs Python 3 and `pip install rubymarshal`, and never writes anything.)
   - Exit code 0 = slot is free. Continue to step 1.
   - Any non-zero exit = STOP. Do not copy anything into Data/ or Graphics/.
     Exit 1: the slot is taken. The last output line is `DT_SLOT_CHECK {json}` with a
     `free_ids` list. Take the first free id N, then name the map file
     Map<N as 3 digits>.rxdata instead of Map116.rxdata, and re-run the script with N
     as the last argument. Install only once that run exits 0.
     Exit 2: bad arguments or not a game folder -- fix the command.
     Exit 3: the check could not run (usually rubymarshal is missing) -- install it
     and re-run. A check that could not run is NOT a pass; never skip it.
   - A file merely not existing is NOT enough: a free-looking id can still carry the old
     map's name, connections and encounters. The script checks all of that; do not
     replace it with your own look at the Maps tree.
   - Never overwrite an existing Data/Map*.rxdata or an existing tileset entry.

1. Register the tileset:
   a. Copy Tileset_flamingo-inside__imported_-slot116-flamingo-inside_imported_2.png into Graphics/Tilesets/.
   b. Open RPG Maker XP -> Database -> Tilesets. Add one new entry
      pointing at Tileset_flamingo-inside__imported_-slot116-flamingo-inside_imported_2.png, and note the ID it gets assigned.
   c. If that ID is DIFFERENT from 43 (the "Tileset ID" you
      entered when you ran this export) -- STOP here. Go back to the
      Export step in the app and re-export with the real ID entered
      instead. Map116.rxdata references tileset 43
      internally, so a mismatch does not mean a slightly-wrong tileset:
      it means RPG Maker draws this map's tiles from WHATEVER tileset
      already holds that ID today. Since this map uses many tile ids
      well past 384, and any of your existing tilesets is almost
      certainly a shorter sheet, most or all of the picture will render
      as solid black/blank -- "the background is not shown" is exactly
      this symptom, not a sign the export itself is empty. Only
      continue to step 2 once the ID you exported with matches the ID
      RPG Maker actually assigned.

2. Copy Map116.rxdata into Data/ (or Map<N>.rxdata if step 0 gave you another id).
   - Only after step 0 exited 0 for exactly that id. Do not overwrite an existing file.

passability.csv and the .json are reference only (see their own headers) --
this export never writes Data/Tilesets.rxdata, so passability/priority
still needs the one-time manual Database step above.

3. Traced background objects -- per-object Database steps:
   - "tim" (Layer 3): set tileset rows 51-54 (tile ids 784-809) to Priority 4 (the per-tile values in passability.csv, 1-4, are more exact), so the player can walk behind it.
     Its base row stays on Ground (not a new tile) -- also set tile id(s) 649, 650, 657, 658 to Passage x so the base still blocks.
   - "yayoi" (Layer 3): set tileset rows 55-59 (tile ids 816-849) to Priority 5 (the per-tile values in passability.csv, 1-5, are more exact), so the player can walk behind it.
     Its base row stays on Ground (not a new tile) -- also set tile id(s) 459, 460, 467, 468 to Passage x so the base still blocks.
   - "dolly" (Layer 3): set tileset rows 60-63 (tile ids 856-882) to Priority 4 (the per-tile values in passability.csv, 1-4, are more exact), so the player can walk behind it.
     Its base row stays on Ground (not a new tile) -- also set tile id(s) 697, 698, 705, 706 to Passage x so the base still blocks.
   - "ada" (Layer 3): set tileset rows 64-68 (tile ids 888-922) to Priority 5 (the per-tile values in passability.csv, 1-5, are more exact), so the player can walk behind it.
     Its base row stays on Ground (not a new tile) -- also set tile id(s) 515, 516, 517, 523, 524, 525 to Passage x so the base still blocks.

GRID, SCALE AND PADDING
  Grid size: 64 px per square, offset X 6 Y 3.
  Map: 13 x 24 whole tiles (416 x 768 px).
  Scale: 1/2. Every 64px grid square of art became one 32px tile, resampled nearest-neighbour. The player (32x48) is 2x bigger relative to the map than it would be at a 32px grid.
  Padded with the map's edge colour (art px, before scaling): left 58, right 22, top 61, bottom 52, so the map is whole tiles.

TILESET SHEET LAYOUT -- read this before editing the PNG by hand

   The sheet is your map, not a bag of tiles. It is cut into 2 vertical
   strip(s) of 8 tiles (256px) each, stacked top to bottom:
     strip 1: map columns 1-8, all 24 map rows -> sheet rows 1-24
     strip 2: map columns 9-13, all 24 map rows -> sheet rows 26-49
   The last strip only uses 5 of its 8 columns -- the rest is transparent padding.

   A solid CYAN row separates one strip from the next. No map tile ever
   points at a cyan tile. Leave the cyan rows where they are: every tile
   id is its position on this sheet, so inserting or deleting a row shifts
   every id below it and the .rxdata would then draw the wrong picture.

   To fix a tile: find it on the sheet where it sits on the map, paint over
   it in place, save, and copy the PNG back into Graphics/Tilesets/. Tile ids
   do not change, so the map keeps working with no re-export.

   Keep the PNG exactly 256px wide and its height a multiple of 32px.

   Below the last strip, after one more cyan row, sit the extra cut-out
   tiles: transparent-masked copies of placed sprites and traced objects,
   used on layers 2/3. Each object is its own block, starting on a fresh row
   and shaped like the object on the map (an object wider than 8 tiles is cut
   into stacked 8-column strips). Blocks never share a sheet row. A tile in a
   block that no map cell uses is just unused space.

   (Strip-and-stack layout adopted from Evyatar's assets-factory/
   create_tileset.py in github.com/evyatar100/DESERT-TOWN.)
